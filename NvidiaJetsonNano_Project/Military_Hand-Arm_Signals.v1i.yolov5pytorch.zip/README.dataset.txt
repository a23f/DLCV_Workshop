# Military_Hand&Arm_Signals > 2022-08-03 3:45am
https://universe.roboflow.com/object-detection/military_hand-arm_signals

Provided by Roboflow
License: CC BY 4.0

